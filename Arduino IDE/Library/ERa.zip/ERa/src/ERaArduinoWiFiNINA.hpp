#ifndef INC_ERA_ARDUINO_WIFI_NINA_HPP_
#define INC_ERA_ARDUINO_WIFI_NINA_HPP_

#define ERA_MODBUS

#include <ERaSimpleArduinoWiFiNINA.hpp>

#endif /* INC_ERA_ARDUINO_WIFI_NINA_HPP_ */
