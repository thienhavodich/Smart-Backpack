#ifndef INC_ERA_STATIC_HPP_
#define INC_ERA_STATIC_HPP_

#include <ERa/ERaApiStatic.hpp>
#include <ERa/ERaPropertyStatic.hpp>
#include <ERa/ERaProtocolStatic.hpp>
#include <Modbus/ERaModbusDataStatic.hpp>

#endif /* INC_ERA_STATIC_HPP_ */
