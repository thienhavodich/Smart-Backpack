#ifndef INC_ERA_REALTEK_SSL_HPP_
#define INC_ERA_REALTEK_SSL_HPP_

#define ERA_MODBUS

#include <ERaSimpleRealtekSSL.hpp>

#endif /* INC_ERA_REALTEK_SSL_HPP_ */
