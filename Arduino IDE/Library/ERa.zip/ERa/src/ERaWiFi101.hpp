#ifndef INC_ERA_WIFI_101_HPP_
#define INC_ERA_WIFI_101_HPP_

#define ERA_MODBUS

#include <ERaSimpleWiFi101.hpp>

#endif /* INC_ERA_WIFI_101_HPP_ */
