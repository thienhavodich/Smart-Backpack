#ifndef INC_ERA_ARDUINO_WIFI_HPP_
#define INC_ERA_ARDUINO_WIFI_HPP_

#define ERA_MODBUS

#include <ERaSimpleArduinoWiFi.hpp>

#endif /* INC_ERA_ARDUINO_WIFI_HPP_ */
