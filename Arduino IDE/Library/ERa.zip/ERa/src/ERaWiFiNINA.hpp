#ifndef INC_ERA_WIFI_NINA_HPP_
#define INC_ERA_WIFI_NINA_HPP_

#define ERA_MODBUS

#include <ERaSimpleWiFiNINA.hpp>

#endif /* INC_ERA_WIFI_NINA_HPP_ */
