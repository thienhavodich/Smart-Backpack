#ifndef INC_ERA_SERIAL_HPP_
#define INC_ERA_SERIAL_HPP_

#define ERA_MODBUS
#define ERA_ZIGBEE

#include <ERaSimpleSerial.hpp>

#endif /* INC_ERA_SERIAL_HPP_ */
